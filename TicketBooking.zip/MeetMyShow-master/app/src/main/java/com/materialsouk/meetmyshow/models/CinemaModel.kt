package com.materialsouk.meetmyshow.models

class CinemaModel(
    val cinemaName: String,
    val cinemaLocation: String,
    val cinemaDrawable: String
)
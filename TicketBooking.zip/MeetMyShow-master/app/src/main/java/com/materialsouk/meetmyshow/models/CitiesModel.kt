package com.materialsouk.meetmyshow.models

data class CitiesModel(
    val city:String,
    var isChecked :Boolean = false
)
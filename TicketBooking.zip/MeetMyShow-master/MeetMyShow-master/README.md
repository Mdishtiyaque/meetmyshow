# MeetMyShow
Online Movie Ticket Booking App 
Built clone of BookMyShow ticket booking app using Kotlin
# Screenshot
<div style="display:flex;">
<img src="screenshot/1.jpeg" width="23%">
<img src="screenshot/2.jpeg" width="23%">
<img src="screenshot/3.jpeg" width="23%">
<img src="screenshot/4.jpeg" width="23%">
</div>


<div style="display:flex;">
<img src="screenshot/5.jpeg" width="23%">
<img src="screenshot/6.jpeg" width="23%">
<img src="screenshot/7.jpeg" width="23%">
<img src="screenshot/8.jpeg" width="23%">
</div>


<div style="display:flex;">
<img src="screenshot/9.jpeg" width="23%">
<img src="screenshot/10.jpeg" width="23%">
<img src="screenshot/11.jpeg" width="23%">
<img src="screenshot/12.jpeg" width="23%">
</div>



<div style="display:flex;">
<img src="screenshot/13.jpeg" width="23%">
<img src="screenshot/14.jpeg" width="23%">
<img src="screenshot/15.jpeg" width="23%">
<img src="screenshot/16.jpeg" width="23%">
</div>

# [Project Report](https://github.com/meet2602/MeetMyShow/blob/master/screenshot/Project%20Report.pdf)
# [All Diagram](https://github.com/meet2602/MeetMyShow/tree/master/screenshot/diagram)
# [Sample Data](https://github.com/meet2602/MeetMyShow/tree/master/screenshot/movie_sample_data.json)

# [YouTube Video Link](https://youtu.be/qzM71WWkyK4)

